---
layout: default
title: people
permalink: /people/
---

### Current Graduate Students

- Ruining Gao, MS student
- Aohan Mei, MS student
- Xiaozhen Xu, MS student
- Haoxiang Zhang, MS student
- Yi Wang, MS student
- Can Li, MS student
- Xinming Guo, MS student
- Yangshuo Bai, MS student

### Alumni

- Zhihe Yin, MS student (2025, First employment: Huawei)
- Yanxiao Zhai, MS student (2025, First employment: Jiangsu Yinhang)
- Congcong Zhang, MS student (2025, First employment: Huawei)
